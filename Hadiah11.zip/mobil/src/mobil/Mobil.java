/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mobil;
import java.awt.*;
import java.util.HashSet;
import java.util.Set;

public class Mobil extends Panel {
    Font f;
    String text="Ini mobilnya Eve";
    Mobil() {
        setBackground(Color.WHITE);
    }
    public void paint(Graphics g) {
        //tulisan
        f = new Font("Helvetica",Font.BOLD,38);
        //bagian atas
        g.setColor(Color.CYAN);
        g.drawRect(50,10, 300,90);
        g.fillRect(50,10,300,90);
        //bagian bawah
        g.setColor(Color.CYAN);
        g.drawRect(50,100,475,130);
        g.fillRect(50,100,475,130);
        //roda 1
        g.setColor(Color.red);
        g.drawOval(80,120,140,140);
        g.fillOval(80,120,140,140);
        //roda 2
        g.setColor(Color.red);
        g.drawOval(300,120,140,140);
        g.fillOval(300,120,140,140);
        //WARNA tulisan
        g.setColor(Color.BLACK);
        g.setFont(f);
        g.drawString(text, 550,75);
        
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Frame f = new Frame("Hadiah Teori");
        Mobil gp = new Mobil();
        f.add(gp);
        f.setSize(900,900);
        f.setVisible(true);
    }
    
}
